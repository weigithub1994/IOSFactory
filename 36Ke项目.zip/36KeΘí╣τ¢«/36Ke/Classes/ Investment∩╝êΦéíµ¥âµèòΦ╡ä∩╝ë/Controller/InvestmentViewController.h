//
//  InvestmentViewController.h
//  36Ke
//
//  Created by lmj on 16/3/21.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InvestmentViewController : UIViewController

@end
