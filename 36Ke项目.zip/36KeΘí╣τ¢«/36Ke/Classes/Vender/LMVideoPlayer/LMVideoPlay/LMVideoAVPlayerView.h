//
//  LMVideoAVPlayerView.h
//  LMVideoPlay
//
//  Created by lmj  on 16/3/18.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>
@interface LMVideoAVPlayerView : UIView

@property (nonatomic ,strong) AVPlayer *player;


@end
