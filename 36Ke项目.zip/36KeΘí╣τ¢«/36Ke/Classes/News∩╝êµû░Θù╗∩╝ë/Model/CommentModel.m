//
//  CommentModel.m
//  36Ke
//
//  Created by lmj  on 16/3/9.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import "CommentModel.h"

@implementation CommentModel

@end
@implementation CommentData

+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [CommentData2 class]};
}

@end


@implementation CommentData2

@end



