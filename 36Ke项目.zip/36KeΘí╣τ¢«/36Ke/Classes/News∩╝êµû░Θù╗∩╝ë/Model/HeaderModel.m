//
//  HeaderModel.m
//  36Ke
//
//  Created by lmj  on 16/3/3.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import "HeaderModel.h"

@implementation HeaderModel

@end
@implementation HeaderData

+ (NSDictionary *)objectClassInArray{
    return @{@"pics" : [Pics class]};
}

@end


@implementation Pics

@end


