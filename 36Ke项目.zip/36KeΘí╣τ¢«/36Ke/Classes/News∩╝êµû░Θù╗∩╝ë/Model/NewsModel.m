//
//  NewsModel.m
//  36Ke
//
//  Created by lmj  on 16/3/3.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import "NewsModel.h"

@implementation NewsModel

@end
@implementation NewsData

+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [ChildData class]};
}

@end


@implementation ChildData

@end


@implementation User

@end


