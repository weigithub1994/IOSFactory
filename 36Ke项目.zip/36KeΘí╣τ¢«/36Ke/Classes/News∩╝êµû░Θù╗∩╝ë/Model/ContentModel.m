//
//  ContentModel.m
//  36Ke
//
//  Created by lmj  on 16/3/9.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import "ContentModel.h"

@implementation ContentModel

@end
@implementation ContentData




@end


@implementation ContentUser

//- (instancetype)initWithDict:(NSDictionary *)dict
//{
//    ContentUser *userContent = [[ContentUser alloc] init];
//    if (self) {
////        userContent.name = dict[@"name"];
////        userContent.avatar = dict[@"avatar"];
////        userContent.ssoId = [dict[@"ssoId"] integerValue];
//    }
//    return userContent;
//}


@end


