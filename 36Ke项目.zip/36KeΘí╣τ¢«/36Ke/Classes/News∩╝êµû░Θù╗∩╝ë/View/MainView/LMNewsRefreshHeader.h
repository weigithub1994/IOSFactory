//
//  LMNewsRefreshHeader.h
//  36Ke
//
//  Created by lmj  on 16/3/3.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface LMNewsRefreshHeader : MJRefreshGifHeader

@end
