//
//  CompanyView.m
//  36Ke
//
//  Created by lmj  on 16/3/9.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import "CompanyView.h"

@implementation CompanyView

@end
