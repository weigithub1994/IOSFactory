//
//  NewCommentCell.h
//  36Ke
//
//  Created by lmj  on 16/3/10.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewCommentCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@end
