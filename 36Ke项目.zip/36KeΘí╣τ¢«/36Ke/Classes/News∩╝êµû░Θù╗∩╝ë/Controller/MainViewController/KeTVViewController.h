//
//  KeTVViewController.h
//  36Ke
//
//  Created by lmj  on 16/3/9.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeTVViewController : UIViewController

//@property (nonatomic)
- (instancetype)initColumn:(NSString *)column title:(NSString *)title;

@end
