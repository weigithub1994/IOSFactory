//
//  KeTVModel.m
//  36Ke
//
//  Created by lmj  on 16/3/9.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import "KeTVModel.h"

@implementation KeTVModel

@end
@implementation KeTVData1

+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [KeTVData2 class]};
}

@end


@implementation KeTVData2

@end


@implementation KeTv

@end


