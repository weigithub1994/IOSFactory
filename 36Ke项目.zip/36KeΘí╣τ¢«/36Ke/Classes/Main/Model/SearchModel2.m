//
//  SearchModel2.m
//  36Ke
//
//  Created by lmj  on 16/3/21.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import "SearchModel2.h"

@implementation SearchModel2

@end
@implementation DataSearch

+ (NSDictionary *)objectClassInArray{
    return @{@"org" : [Org1 class], @"company" : [Company2 class], @"user" : [User345 class]};
}

@end


@implementation Org1

@end


@implementation Company2

@end


@implementation User345

@end


