//
//  LMNavigationController.h
//  36Ke
//
//  Created by lmj  on 16/3/3.
//  Copyright (c) 2016年 lmj . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMNavigationController : UINavigationController

- (void)showMenu;

@end
