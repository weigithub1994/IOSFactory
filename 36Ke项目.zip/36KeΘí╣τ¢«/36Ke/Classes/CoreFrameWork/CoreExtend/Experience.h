//
//  Experience.h
//  CoreExtend
//
//  Created by 成林 on 15/4/6.
//  Copyright (c) 2015年 muxi. All rights reserved.
//

/*
 
 1.使用CocoaPods导入头文件不能提示？
   在BuildSettings中搜索Header Search Path，然后设置$(PODS_ROOT),并勾选recursive支持递归搜索。
 
 2.代码片段路径：~/Library/Developer/Xcode/UserData/CodeSnippets
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 */

