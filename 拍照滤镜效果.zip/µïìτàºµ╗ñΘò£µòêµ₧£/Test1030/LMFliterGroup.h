//
//  LMFliterGroup.h
//  Test1030
//
//  Created by xx11dragon on 15/11/4.
//  Copyright © 2015年 xx11dragon. All rights reserved.
//

#import "GPUImageFilterGroup.h"

@interface GPUImageFilterGroup(addTitleColor)

@property (nonatomic , copy) NSString *title;

@property (nonatomic , strong) UIColor *color;


@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com