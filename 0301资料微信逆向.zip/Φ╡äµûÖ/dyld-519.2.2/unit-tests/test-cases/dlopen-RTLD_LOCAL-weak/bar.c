int __attribute__((weak)) A[] = { 1, 2, 3, 4 };


int* getA() { return A; }

