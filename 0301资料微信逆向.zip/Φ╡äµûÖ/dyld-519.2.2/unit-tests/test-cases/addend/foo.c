

const char a = 10;
const char b = 11;
const char c = 12;
const char d = 13;
const char e = 14;
