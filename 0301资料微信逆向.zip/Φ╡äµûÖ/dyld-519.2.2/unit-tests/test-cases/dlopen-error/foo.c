
void foo() {}
