
void base() { }

