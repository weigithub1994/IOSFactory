int bar()
{
	return VALUE;
}

