
int bar() {
    return 42;
}

