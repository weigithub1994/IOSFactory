

extern int slipperySymbol;

int main()
{
    return slipperySymbol;
}
