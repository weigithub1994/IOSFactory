
void foo()
{
}

