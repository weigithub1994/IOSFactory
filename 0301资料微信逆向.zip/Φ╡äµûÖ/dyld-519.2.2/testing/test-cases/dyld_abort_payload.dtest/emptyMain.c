#include <stdlib.h>

int main(int argc, const char* argv[])
{
   return 1;
}

