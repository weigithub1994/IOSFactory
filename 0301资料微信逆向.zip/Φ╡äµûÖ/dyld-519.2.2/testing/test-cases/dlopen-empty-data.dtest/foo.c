
int dummy;

int foo()
{
	return 10;
}

